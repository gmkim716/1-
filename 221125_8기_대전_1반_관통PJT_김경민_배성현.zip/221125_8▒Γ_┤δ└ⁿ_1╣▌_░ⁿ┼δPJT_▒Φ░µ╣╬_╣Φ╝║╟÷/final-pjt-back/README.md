### 사용전 읽어보기
---
* $ pip install django==3.2.13							# 장고 설치
* $ django-admin startproject firstpjt .		# 프로젝트 생성



## 작업내용
---
* json 데이터 가져오기 -> db에 저장할 수 있을까?	(11/15)
* movie_pjt 프로젝트 생성
* movies 앱 생성
